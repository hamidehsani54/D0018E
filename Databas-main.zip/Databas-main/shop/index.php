<?php


session_start();
	include("cPanel/connection.php");
	include("cPanel/function.php");
  //hämtar användarens info
	$userInfo = userInfo($conn);
  //hämtar produkt info från databas
	$result = mysqli_query($conn,"SELECT * FROM prod");
	$userID = $userInfo['user_id'];
  //visar antal produkter i varukoregen
	$getCartsCount = getCartsCount($conn);	
  //visar nya meddelandet
  $newMessagesCount = getNewMessageCountUser($conn,$userID);
  //hämtar hemsidansinställningar
  $getSiteSetting = getSiteSetting($conn);
  //om kunden har clickat på köp då varan läggs till i varukorgen 
  if ($_SERVER['REQUEST_METHOD'] == "POST" && isset($_POST['buyClick'])){
    $prodid = $_POST['prodid'];
    header("location: cPanel/addtocart.php?id=$prodid&u=$userID");
  }
?>
<!DOCTYPE html>
<html>
<head>
	<title><?php echo $getSiteSetting['site_name'] ?></title>
  <meta name="description" content="<?php echo $getSiteSetting['site_desc'] ?>">
  <meta name="keywords" content="<?php echo $getSiteSetting['site_meta'] ?>">
  <link rel="stylesheet" href="frontend.css">
</head>

<body>
	<div class="header">
  <img src="cPanel/image/logo.png" alt="MobileShop" />
</div><br><br>
  <?php  

  //om personen är inte inloggad 
  if ($userID < 1){ 
  ?>
  <ul>
    <li><a href="index.php">Hem</a></li>
  <li><a href="product.php">Produkter</a></li>
  <li><a href="login.php">Logga in</a></li>
  <li><a href="signup.php">Registera</a></li>
  </ul>
  <?php
   } else {
  ?>
  <!-- om personen är inloggad -->
  <ul>
  <li><a href="index.php">Hem</a></li>
  <li><a href="product.php">Produkter</a></li>
  <li><a href="history.php">Historik</a></li>
  <li><a href="sendmessages.php">Kontakta admin</a></li>
  <li><a href="messages.php">Meddelanden: <?php  echo $newMessagesCount?></a></li>
  <li id="navright"><a href="logout.php">Logga ut</a></li>
  <li id="navrightbg"><a href="cart.php">Varukorgen: <?php  echo $getCartsCount?></a></li>
  <li id="navrightbg"><a href="profile.php"><?php  echo $userInfo['Fname']?></a></li>
  </ul>
  <?php
   } 
  ?>
 
  <?php
  //kollar om produkter finns i databastabellen och visar den på skärmen beroende på vad admin har bestämt 
  if ($result->num_rows > 0) {
  	for ($i=0; $i < $getSiteSetting['prod_nr']; $i++) { 
  		$row = $result->fetch_assoc();
  ?>
  <!-- Produktsinformation  -->
  <div class="card">
  <a href="prodview.php?id=<?php echo $row["prod_id"];?>"><img src="cPanel/image/<?php echo $row["prod_image"];?>"></a>
  <h2><a href="prodview.php?id=<?php echo $row["prod_id"];?>"><?php echo $row["prod_title"];?></a></h2>
  <p class="price"><?php echo $row["prod_price"];?> kr</p>
  <?php 

  //kollar om varan är slut i lager
  if ($row["prod_count"] == 0) {
    echo '<p><button>Slut i lager</button></p>';
  }
  else{
    //kollar om varan finns i lager och då ska gå att köpa
    ?>
    <p>Antal i lager <?php echo $row["prod_count"];?></p>
    <form method="post">
      <input type="submit" name="buyClick" value="KÖP">
      <input type="hidden" name="prodid" value="<?php echo $row["prod_id"];?>">
    </form>
    <?php
  }
  ?>

</div>
  <?php
  }
} 
  ?>


	<div class="footer">
      <div class="nav">
        <ul>
          <li><a href="#">Om oss</a></li>
          <li><a href="#">Kontakta oss</a></li>
        </ul>
      </div>
   </div>

   <div class="footer-end">
      <p>Hemsidan skapat av: Ameer Alkadhimi, Pehr Häqqvist och Hamid Ehsani - 2021</p>
   </div>
	
</body>
</html>