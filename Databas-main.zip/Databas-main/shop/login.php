<?php
	session_start();
	include("cPanel/connection.php");
	include("cPanel/function.php");
	$userInfo = userInfo($conn);
	$getSiteSetting = getSiteSetting($conn);
	if ($_SERVER['REQUEST_METHOD'] == "POST"){
		$email = $_POST['email'];
		$password = $_POST['passwordvalue'];

		//ifall den är tom
		if (empty($email) || empty($password)) {
			echo "Du måste fylla epost och lösenord";
		}
		else {	

			//kontrollerar om email/lösenord finns i databas
			$result = mysqli_query($conn, "SELECT * from users WHERE user_email = '$email' limit 1");
			if($result){
				//kontrollerar om lösenordet är rätt
				if ($result && mysqli_num_rows($result) > 0) {
				$user_data = mysqli_fetch_assoc($result);
					if($user_data['user_password'] === $password){
						$_SESSION['user_id'] = $user_data['user_id'];
						header("Location: index.php");
					}
					else{
						echo "Fel E-post eller lösenord !";
					}
			    }
			}
		}
	}
?>

<!DOCTYPE html>
<html>
<head>
	<title><?php echo $getSiteSetting['site_name'] ?></title>
  <meta name="description" content="<?php echo $getSiteSetting['site_desc'] ?>">
  <meta name="keywords" content="<?php echo $getSiteSetting['site_meta'] ?>">
  <link rel="stylesheet" href="frontend.css">
</head>
<body>
	<div class="header">
  <img src="cPanel/image/logo.png" alt="MobileShop" />
</div><br><br>
  <ul>
  <li><a href="index.php">Hem</a></li>
  <li><a href="product.php">Produkter</a></li>
  <li><a href="login.php">Logga in</a></li>
  <li><a href="signup.php">Registrera</a></li>
  </ul>
  <br><br><label class="pagetitle">Logga in</label><br><br>
	<div class="signbox">
		<form method="post">
			<input type="email" placeholder="E-post" name="email"><br><br>
			<input type="password" placeholder="lösenord" name="passwordvalue" minlength="6"><br><br>
			<input id="sub" type="submit" value="Logga in"><br><br>
			<a id="boldtext" href="forgetpass.php">Glömt lösenord</a><br>
			<a id="boldtext" href="signup.php">Registrera</a>
		</form>		
	</div>
	<div class="footer">
      <div class="nav">
        <ul>

          <li><a href="#">Om oss</a></li>
          <li><a href="#">Kontakta oss</a></li>
        </ul>
      </div>
   </div>

   <div class="footer-end">
      <p>Hemsidan skapat av: Ameer Alkadhimi, Pehr Häqqvist och Hamid Qurban - 2021</p>
   </div>
</body>
</html>
