<?php
session_start();

	include("cPanel/connection.php");
  include("cPanel/function.php");
  $userInfo = userInfo($conn);
  $idUser = $userInfo ['user_id'];
  $newMessagesCount = getNewMessageCountUser($conn,$idUser);
  $getCartsCount = getCartsCount($conn);
  $getSiteSetting = getSiteSetting($conn);
    if($idUser < 1) {
      header("location: login.php");
    }
    //msgID fårgas från länken
  $msgId = $_GET['msgId'];
  $user = "användare";
  //hämtar alla meddelandettext för specifik meddelande
  $msgInfo = mysqli_query($conn,"SELECT * FROM msg  WHERE mess_id = $msgId");
  //hämtar meddelandeinformation för meddelande 
  $messageStatus = mysqli_query($conn,"SELECT * FROM messages WHERE message_id = $msgId");
  $getMessageStatus = mysqli_fetch_assoc($messageStatus);
  //om "send" är klickad
   if ($_SERVER['REQUEST_METHOD'] == "POST" && isset($_POST['send'])){
    $message = $_POST['message'];
    mysqli_begin_transaction($conn);
      try{
        //lägger till meddelandetexten i databas 
        mysqli_query($conn, "INSERT into msg (mess_id, msg_user, msg_title, msg_text) values ('$msgId', '$idUser', '$user', '$message')");
        //ändra meddelande status
        mysqli_query($conn, "UPDATE messages SET message_user_status = 1, message_admin_status = 0  WHERE message_id = $msgID");
        mysqli_commit($conn);
      } catch (mysqli_sql_exception $exception) {
          mysqli_rollback($conn);
          throw $exception;
      }

    header("location: readmessage.php?msgId=$msgId");
   }

?>
<!DOCTYPE html>
<html>
<head>
  <title><?php echo $getSiteSetting['site_name'] ?> - Meddelande</title>
  <meta name="description" content="<?php echo $getSiteSetting['site_desc'] ?>">
  <meta name="keywords" content="<?php echo $getSiteSetting['site_meta'] ?>">
  <link rel="stylesheet" href="frontend.css">
</head>
<body>
  <div class="header">
  <img src="cPanel/image/logo.png" alt="MobileShop" />
</div><br><br>
	<?php  
	if ($idUser < 1){ 
		header("Location: login.php");
	} 
  ?>
  <ul>
  <li><a href="index.php">Hem</a></li>
  <li><a href="product.php">Produkter</a></li>
  <li><a href="history.php">Historik</a></li>
  <li><a href="sendmessages.php">Kontakta admin</a></li>
  <li><a href="messages.php">Meddelanden: <?php  echo $newMessagesCount?></a></li>
  <li id="navright"><a href="logout.php">Logga ut</a></li>
  <li id="navrightbg"><a href="cart.php">Varukorgen: <?php  echo $getCartsCount?></a></li>
  <li id="navrightbg"><a href="profile.php"><?php  echo $userInfo['Fname']?></a></li>
  </ul>
  <br><br><label class="pagetitle">Meddelanden # <?php echo $msgId ?></label><br><br>
  <?php
  if ($msgInfo->num_rows > 0) {
      while($row = $msgInfo->fetch_assoc()) {
        
        if ($row["msg_user"] == 0) {
          echo '<div class="msgAdmin">';
          echo "<label id='boldtext'>Meddelandet av admin:</label><br><br>";
          echo '<p>' . $row["msg_text"] . ' </p>';
          echo '</div>';
        }
        elseif($row["msg_user"] == $idUser){
          echo '<div class="msgUser">';
           echo "<label id='boldtext'>Meddelandet av kunden:</label><br><br>";
          echo '<p>' . $row["msg_text"] . ' </p>';
          echo '</div>';
        }
      }
    }

    if ($getMessageStatus['message_active'] == 0) {
        ?>
        <div class="formbox">
        <form method="post">
      <label id="fName" for="message">Svara: </label><br>
      <textarea id="messsageArea" name="message"></textarea><br>
      <input id="sub" type="submit" name="send" value="Skicka meddelandet">
    </form> 
    </div>
	   <?php 
      }
     ?>
     <div class="footer">
      <div class="nav">
        <ul>

          <li><a href="#">Om oss</a></li>
          <li><a href="#">Kontakta oss</a></li>
        </ul>
      </div>
   </div>

   <div class="footer-end">
      <p>Hemsidan skapat av: Ameer Alkadhimi, Pehr Häqqvist och Hamid Qurban - 2021</p>
   </div>
</body>
</html>