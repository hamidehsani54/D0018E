<?php
session_start();

	include("connection.php");
	include("function.php");
	$adminInfo = adminInfo($conn);
	$idAdmin = $adminInfo ['admin_id'];
	$orderStatusCount = getOrderStatusCount($conn);
	$newMessageCount = getNewMessageCountAdmin($conn);
	$getSiteSetting = getSiteSetting($conn);
?>
<!DOCTYPE html>
<html>
<head>
  <title><?php echo $getSiteSetting['site_name'] ?> - Kontrollpanalen</title>
  <meta name="description" content="<?php echo $getSiteSetting['site_desc'] ?>">
  <meta name="keywords" content="<?php echo $getSiteSetting['site_meta'] ?>">
  <link rel="stylesheet" href="../frontend.css">
</head>
<body>
<div class="header">
  <img src="image/logo.png" alt="MobileShop" />
</div><br><br>

	<?php  
	if ($idAdmin > 0){ 
	?>
	<ul>
    <li><a href="index.php">Hem</a></li>
    <li><a href="product.php">Produkter</a></li>
    <li><a href="allorder.php">Order</a></li>
    <li><a href="allusers.php">Användare</a></li>
    <li><a href="admins.php">Admins</a></li>
    <li><a href="orderstatus.php">Order status: <?php echo $orderStatusCount ?></a></li>
    <li><a href="messages.php">Meddelandet: <?php  echo $newMessageCount?></a></li>
    <li><a href="setting.php">Inställningar</a></li>
    <li id="navright"><a href="logout.php">Logga ut</a></li>
    <li id="navrightbg"><a href="profile.php"><?php  echo $adminInfo['Aname']?></a></li>
    </ul>   
    <h1>Välkommen till kontrolpanalen <?php  echo $adminInfo['Aname']?> </h1> <br>
    <div class="formbox">
    	<table width="100%">
    		<tr>
		    <th><a href="product.php"><img id="adminicon" src="image/product.png"></a></th>
		    <th><a href="allorder.php"><img id="adminicon" src="image/orders.png"></a></th>
		    <th><a href="setting.php"><img id="adminicon" src="image/setting.png"></a></th>
		  </tr>
		  <tr>
		  	<th id="iconname"><a href="product.php">Produkter</a></th>
		    <th id="iconname"><a href="allorder.php">Alla Order</a></th>
		    <th id="iconname"><a href="setting.php">Inställningar</a></th>
		  </tr>
		  <tr>
		    <th><a href="admins.php"><img id="adminicon" src="image/admins.png"></a></th>
		    <th><a href="allusers.php"><img id="adminicon" src="image/users.png"></a></th>
		    <th><a href="profile.php"><img id="adminicon" src="image/profile.png"></a></th>
		  </tr>
		  <tr>
		  	<th id="iconname"><a href="admins.php">Alla admins</a></th>
		    <th id="iconname"><a href="allusers.php">Alla Användare</a></th>
		    <th id="iconname"><a href="profile.php">Mina sidor</a></th>
		  </tr>
    	</table>
    </div>
	<?php
	 } else {
	 	header("Location: login.php")
	?>
	<a href="login.php">Logga in</a>
	<?php
	 } 
	?>
	<div class="footer">
      <div class="nav">
        <ul>
          <li><a href="index.php">Hem</a></li>
          <li><a href="product.php">Produkter</a></li>
          <li><a href="#">Om oss</a></li>
          <li><a href="#">Kontakta oss</a></li>
        </ul>
      </div>
   </div>

   <div class="footer-end">
      <p>Hemsidan skapat av: Ameer Alkadhimi, Pehr Häqqvist och Hamid Qurban - 2021</p>
   </div>
</body>
</html>