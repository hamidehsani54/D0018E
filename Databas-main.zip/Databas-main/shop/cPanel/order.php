<?php
session_start();

  include("connection.php");
  include("function.php");
  $adminInfo = adminInfo($conn);
  $idAdmin = $adminInfo ['admin_id'];
  $orderStatusCount = getOrderStatusCount($conn);
  $newMessageCount = getNewMessageCountAdmin($conn);
  $getSiteSetting = getSiteSetting($conn);
  $id = $_GET['id'];

  $orderConnection = mysqli_query($conn,"SELECT * FROM ordersprod JOIN orders ON orders.order_id = ordersprod.o_order_id WHERE ordersprod.o_order_id = $id");
  if(!isset($_SESSION['admin_id'])) {
      header("location: login.php");
    }
?>
<!DOCTYPE html>
<html>
<head>
  <title><?php echo $getSiteSetting['site_name'] ?> - Kontrollpanalen</title>
  <meta name="description" content="<?php echo $getSiteSetting['site_desc'] ?>">
  <meta name="keywords" content="<?php echo $getSiteSetting['site_meta'] ?>">
  <link rel="stylesheet" href="../frontend.css">
</head>
<body>
  <div class="header">
  <img src="image/logo.png" alt="MobileShop" />
</div><br><br>
  <?php  
  if ($idAdmin < 1){ 
    header("location: login.php");
   } else {
  ?>
   <ul>
    <li><a href="index.php">Hem</a></li>
    <li><a href="product.php">Produkter</a></li>
    <li><a href="allorder.php">Order</a></li>
    <li><a href="allusers.php">Användare</a></li>
    <li><a href="admins.php">Admins</a></li>
    <li><a href="orderstatus.php">Order status: <?php echo $orderStatusCount ?></a></li>
    <li><a href="messages.php">Meddelandet: <?php  echo $newMessageCount?></a></li>
    <li><a href="setting.php">Inställningar</a></li>
    <li id="navright"><a href="logout.php">Logga ut</a></li>
    <li id="navrightbg"><a href="profile.php"><?php  echo $adminInfo['Aname']?></a></li>
    </ul>  
    <br><br><label class="pagetitle">Order</label><br><br>    
  <?php
   } 
   ?>
   <table id="alltable">
  <tr>
    <th width="10%"></th>
    <th width="40%">Produkt</th>
    <th width="10%">Artikelnummer</th>
    <th width="15%">Pris</th>
    <th width="10%">Antal</th>
    <th width="15%">Summa</th>
  </tr>
  <?php

  if ($orderConnection->num_rows > 0) {
    while ($orderDetails = $orderConnection->fetch_assoc()) {
      $orderID = $orderDetails['o_order_id'];
      $orderDate = $orderDetails['order_date'];
      $prodID = $orderDetails['product_id'];
      $orderSum = $orderDetails['order_sum'];
      $countSum = $orderDetails['order_prod_count'];
      $prodConn = mysqli_query($conn,"SELECT * from prod WHERE prod_id = '$prodID'");
      $getProd = mysqli_fetch_assoc($prodConn);

      ?>
    <tr>
    <td width="10%"><?php echo'<img height="50" width="40" src="image/'.$getProd ['prod_image'].'">' ?></td>
    <td width="40%"><?php echo $getProd ['prod_title'] ?></td>
    <td width="10%"><?php echo $prodID?></td>
    <td width="15%"><?php echo $orderDetails['o_prod_price'] ?> kr</td>
    <td width="10%"><?php echo $orderDetails['o_count'] ?></td>
    <td width="15%"><?php echo $tot = $orderDetails['o_prod_price'] * $orderDetails['o_count']; ?> kr</td>
  </tr>
    <?php 
    }
  }
      
  ?>
  <tr>
    <td width="10%"></td>
    <td width="40%"></td>
    <td width="10%"></td>
    <td width="15%"></td>
    <td id="boldtext" width="10%">Antal produkter</td>
    <td id="boldtext"  width="15%">Total summa</td>
  </tr>
  <tr>
    <td width="10%"></td>
    <td width="40%"></td>
    <td width="10%"></td>
    <td width="15%"></td>
    <td id="boldtext" width="10%"><?php echo $countSum ?></td>
    <td id="boldtext" width="15%"><?php echo $orderSum?> kr</td>
  </tr>
  <h2>Order # <?php echo $orderID; ?></h2>
   <label>Datum och tid : <?php echo $orderDate ?></label><br><br>
  </table>
  <div class="footer">
      <div class="nav">
        <ul>
          <li><a href="index.php">Hem</a></li>
          <li><a href="product.php">Produkter</a></li>
          <li><a href="#">Om oss</a></li>
          <li><a href="#">Kontakta oss</a></li>
        </ul>
      </div>
   </div>

   <div class="footer-end">
      <p>Hemsidan skapat av: Ameer Alkadhimi, Pehr Häqqvist och Hamid Qurban - 2021</p>
   </div>

</body>
</html>