<?php
session_start();

  include("connection.php");
  include("function.php");
  $adminInfo = adminInfo($conn);
  $orderStatusCount = getOrderStatusCount($conn);
  $newMessageCount = getNewMessageCountAdmin($conn);
  $getSiteSetting = getSiteSetting($conn);
  $idAdmin = $adminInfo ['admin_id'];
    if($idAdmin < 1) {
      header("location: login.php");
    }
  $msgId = $_GET['msgId'];
  $admin = "admin";
  $zero = 0;
  $msgInfo = mysqli_query($conn,"SELECT * FROM msg  WHERE mess_id = $msgId");
  $messageStatus = mysqli_query($conn,"SELECT * FROM messages WHERE message_id = $msgId");
  $getMessageStatus = mysqli_fetch_assoc($messageStatus);
   if ($_SERVER['REQUEST_METHOD'] == "POST" && isset($_POST['send'])){
    $message = $_POST['message'];
    mysqli_begin_transaction($conn);
      try{
     mysqli_query($conn, "INSERT into msg (mess_id, msg_user, msg_title, msg_text) values ('$msgId', 0, '$admin', '$message')");
     mysqli_query($conn, "UPDATE messages SET message_user_status = 0, message_admin_status = 1  WHERE message_id = $msgID");
     mysqli_commit($conn);
          } catch (mysqli_sql_exception $exception) {
              mysqli_rollback($conn);
              throw $exception;
          }
       header("location: readmessage.php?msgId=$msgId");
   }
?>
<!DOCTYPE html>
<html>
<head>
  <title><?php echo $getSiteSetting['site_name'] ?> - Kontrollpanalen</title>
  <meta name="description" content="<?php echo $getSiteSetting['site_desc'] ?>">
  <meta name="keywords" content="<?php echo $getSiteSetting['site_meta'] ?>">
  <link rel="stylesheet" href="../frontend.css">
</head>
<body>
  <div class="header">
  <img src="image/logo.png" alt="MobileShop" />
</div><br><br>
  <?php  
  if ($idAdmin < 1){ 
    header("Location: login.php");
  }
  ?> 
  <ul>
    <li><a href="index.php">Hem</a></li>
    <li><a href="product.php">Produkter</a></li>
    <li><a href="allorder.php">Order</a></li>
    <li><a href="allusers.php">Användare</a></li>
    <li><a href="admins.php">Admins</a></li>
    <li><a href="orderstatus.php">Order status: <?php echo $orderStatusCount ?></a></li>
    <li><a href="messages.php">Meddelandet: <?php  echo $newMessageCount?></a></li>
    <li><a href="setting.php">Inställningar</a></li>
    <li id="navright"><a href="logout.php">Logga ut</a></li>
    <li id="navrightbg"><a href="profile.php"><?php  echo $adminInfo['Aname']?></a></li>
    </ul>    
    <br><br><label class="pagetitle">Meddelanden # <?php echo $msgId ?></label><br><br>
  <?php
  if ($msgInfo->num_rows > 0) {
      while($row = $msgInfo->fetch_assoc()) {
        if ($row["msg_user"] == 0) {
          echo '<div class="msgAdmin">';
          echo "<label>Meddelandet av admin:</label><br><br>";
          echo '<p>' . $row["msg_text"] . ' </p><br><br>';
          echo '</div>';
        }
        else{
          echo '<div class="msgUser">';
           echo "<label>Meddelandet av kunden:</label><br><br>";
          echo '<p>' . $row["msg_text"] . ' </p><br><br>';
          echo '</div>';
        }
        
      }
    }
    if ($getMessageStatus['message_active'] == 0) {
        ?>
        <div class="formbox">
      <form method="post">
      <label id="fName" for="message">Svara: </label><br>
      <textarea id="messsageArea" name="message" style="width: 400px; height: 200px;"></textarea><br><br>
      <input id="sub" type="submit" name="send" value="Skicka meddelandet"> 
    </form> 
    </div>
     <?php 
      }
     ?>
     <div class="footer">
      <div class="nav">
        <ul>
          <li><a href="index.php">Hem</a></li>
          <li><a href="product.php">Produkter</a></li>
          <li><a href="#">Om oss</a></li>
          <li><a href="#">Kontakta oss</a></li>
        </ul>
      </div>
   </div>

   <div class="footer-end">
      <p>Hemsidan skapat av: Ameer Alkadhimi, Pehr Häqqvist och Hamid Qurban - 2021</p>
   </div>
</body>
</html>