<?php
error_reporting(0);
session_start();
include("connection.php");
include("function.php");
$adminInfo = adminInfo($conn);
$idAdmin = $adminInfo ['admin_id'];
$orderStatusCount = getOrderStatusCount($conn);
$newMessageCount = getNewMessageCountAdmin($conn);
$getSiteSetting = getSiteSetting($conn);
if (isset($_POST['addProd'])) {
	$filename = $_FILES["uploadfile"]["name"];
	$tempname = $_FILES["uploadfile"]["tmp_name"];	
	$folder = "image/".$filename;
	$title = $_POST['title'];
	$price = $_POST['price'];
	$count = $_POST['count'];
	$des = $_POST['des'];
		if (empty($title) || empty($price) || empty($count) || empty($des)) {
			echo "Du måste fylla på alla information ";
		}
		else {
			 mysqli_begin_transaction($conn);
      		try{
				mysqli_query($conn,"INSERT INTO prod (prod_title, prod_price, prod_count, prod_des, prod_image) VALUES ('$title', '$price', '$count', '$des', '$filename')");
				move_uploaded_file($tempname, $folder);
				mysqli_commit($conn);
		      } catch (mysqli_sql_exception $exception) {
		          mysqli_rollback($conn);
		           throw $exception;
		        }
				header("Location: product.php");
		}	
}
?>

<!DOCTYPE html>
<html>
<head>
  <title><?php echo $getSiteSetting['site_name'] ?> - Kontrollpanalen</title>
  <meta name="description" content="<?php echo $getSiteSetting['site_desc'] ?>">
  <meta name="keywords" content="<?php echo $getSiteSetting['site_meta'] ?>">
  <link rel="stylesheet" href="../frontend.css">
</head>
</body>
<div class="header">
  <img src="image/logo.png" alt="MobileShop" />
</div><br><br>
<?php  
	if ($idAdmin < 1){ 
		header("Location: login.php");
	 } else {
	?>
	 <ul>
    <li><a href="index.php">Hem</a></li>
    <li><a href="product.php">Produkter</a></li>
    <li><a href="allorder.php">Order</a></li>
    <li><a href="allusers.php">Användare</a></li>
    <li><a href="admins.php">Admins</a></li>
    <li><a href="orderstatus.php">Order status: <?php echo $orderStatusCount ?></a></li>
    <li><a href="messages.php">Meddelandet: <?php  echo $newMessageCount?></a></li>
    <li><a href="setting.php">Inställningar</a></li>
    <li id="navright"><a href="logout.php">Logga ut</a></li>
    <li id="navrightbg"><a href="profile.php"><?php  echo $adminInfo['Aname']?></a></li>
    </ul>  
    <br><br><label class="pagetitle">Lägga till ny produkt</label><br><br>
<div class="formbox">
		<form method="POST" action="" enctype="multipart/form-data">
			<label id="fName" for="title">Titel: </label><br>
			<input type="text" name="title"><br><br>
			<label id="fName" for="price">Pris: </label><br>
			<input type="number" name="price"><br><br>
			<label id="fName" for="count">Antal:</label><br>
			<input type="number" name="count"><br><br>
			<label id="fName" for="des">Beskrivning: </label><br>
			<textarea id="messsageArea" name="des" rows="4" cols="50"></textarea><br>
			<input type="file" name="uploadfile" value=""/><br><br>
			<input type="submit" name="addProd" value="Lägga till"><br><br>
		</form>		
	</div>
	<div class="footer">
      <div class="nav">
        <ul>
          <li><a href="index.php">Hem</a></li>
          <li><a href="product.php">Produkter</a></li>
          <li><a href="#">Om oss</a></li>
          <li><a href="#">Kontakta oss</a></li>
        </ul>
      </div>
   </div>

   <div class="footer-end">
      <p>Hemsidan skapat av: Ameer Alkadhimi, Pehr Häqqvist och Hamid Qurban - 2021</p>
   </div>
	<?php
	 } 
	?>
</body>
</html>
