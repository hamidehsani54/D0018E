<?php
session_start();

	include("connection.php");
	include("function.php");
	$adminInfo = adminInfo($conn);
	$idAdmin = $adminInfo ['admin_id'];
	$orderStatusCount = getOrderStatusCount($conn);
	$newMessageCount = getNewMessageCountAdmin($conn);
	$getSiteSetting = getSiteSetting($conn);
	if ($_SERVER['REQUEST_METHOD'] == "POST"){
		mysqli_begin_transaction($conn);
			try{
		if (isset($_POST['changeUserName'])) {
			$uName = $_POST['userName'];
			mysqli_query($conn, "UPDATE admins SET Aname = '$uName' WHERE admin_id = $idAdmin");
      		header("location: profile.php");
      		
		}
		elseif (isset($_POST['changeEmail'])) {
			$uEmail = $_POST['email'];
			mysqli_query($conn, "UPDATE admins SET admin_email = '$uEmail' WHERE admin_id = $idAdmin");
      		header("location: profile.php");

		}
		elseif (isset($_POST['changePassword'])) {
			$uPassword = $_POST['password'];
			mysqli_query($conn, "UPDATE admins SET admin_password = '$uPassword' WHERE admin_id = $idAdmin");
      		header("location: profile.php");
		}
		mysqli_commit($conn);
          } catch (mysqli_sql_exception $exception) {
              mysqli_rollback($conn);
              throw $exception;
          }
	}
?>
<!DOCTYPE html>
<html>
<head>
  <title><?php echo $getSiteSetting['site_name'] ?> - Kontrollpanalen</title>
  <meta name="description" content="<?php echo $getSiteSetting['site_desc'] ?>">
  <meta name="keywords" content="<?php echo $getSiteSetting['site_meta'] ?>">
  <link rel="stylesheet" href="../frontend.css">
</head>
<body>
	<div class="header">
  <img src="image/logo.png" alt="<?php echo $getSiteSetting['site_name'] ?>" />
  </div><br><br>
	<?php  
	if ($idAdmin < 1){ 
		header("Location: login.php");
	}
	else {
	?>
	<ul>
    <li><a href="index.php">Hem</a></li>
    <li><a href="product.php">Produkter</a></li>
    <li><a href="allorder.php">Order</a></li>
    <li><a href="allusers.php">Användare</a></li>
    <li><a href="admins.php">Admins</a></li>
    <li><a href="orderstatus.php">Order status: <?php echo $orderStatusCount ?></a></li>
    <li><a href="messages.php">Meddelandet: <?php  echo $newMessageCount?></a></li>
    <li><a href="setting.php">Inställningar</a></li>
    <li id="navright"><a href="logout.php">Logga ut</a></li>
    <li id="navrightbg"><a href="profile.php"><?php  echo $adminInfo['Aname']?></a></li>
    </ul>   
    <br><br><label class="pagetitle">Mina sidor</label><br><br>
	<br><br>
	<div class="formbox">
	<form method="post">
	<label id="fName">Username: </label><br>
	<input type="text" name="userName" value="<?php echo $adminInfo ['Aname'] ?>">
	<input id="sub"id="sub" type="submit" name="changeUserName" value="Ändra"><br><br>
	<label id="fName">E-post: </label><br>
	<input type="text" name="email" value="<?php echo $adminInfo ['admin_email'] ?>">
	<input id="sub" type="submit" name="changeEmail" value="Ändra"><br><br>
	<label id="fName">Lösenord: </label><br>
	<input type="password" name="password" value="*********************">
	<input id="sub" type="submit" name="changePassword" value="Ändra"><br><br>
	</form>
	</div>
	<div class="footer">
      <div class="nav">
        <ul>
          <li><a href="index.php">Hem</a></li>
          <li><a href="product.php">Produkter</a></li>
          <li><a href="#">Om oss</a></li>
          <li><a href="#">Kontakta oss</a></li>
        </ul>
      </div>
   </div>

   <div class="footer-end">
      <p>Hemsidan skapat av: Ameer Alkadhimi, Pehr Häqqvist och Hamid Qurban - 2021</p>
   </div>
   <?php
	 } 
	?>
</body>
</html>