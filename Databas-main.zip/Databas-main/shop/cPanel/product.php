<?php
session_start();

  include("connection.php");
  include("function.php");
  $adminInfo = adminInfo($conn);
  $idAdmin = $adminInfo ['admin_id'];
  $orderStatusCount = getOrderStatusCount($conn);
  $newMessageCount = getNewMessageCountAdmin($conn);
  $getSiteSetting = getSiteSetting($conn);
  $result = mysqli_query($conn,"SELECT * FROM prod");
  if ($_SERVER['REQUEST_METHOD'] == "POST"){
    if (isset($_POST['addProd'])) {
      header("location: addProduct.php");
    }
    elseif(isset($_POST['editprod'])){
      $prodid = $_POST['prodid'];
      header("location: editProduct.php?id=$prodid");
    }
    elseif(isset($_POST['delprod'])){
      $prodid = $_POST['prodid'];
      header("location: deleteProduct.php?id=$prodid");
    }
    
  }
?>
<!DOCTYPE html>
<html>
<head>
  <title><?php echo $getSiteSetting['site_name'] ?> - Kontrollpanalen</title>
  <meta name="description" content="<?php echo $getSiteSetting['site_desc'] ?>">
  <meta name="keywords" content="<?php echo $getSiteSetting['site_meta'] ?>">
  <link rel="stylesheet" href="../frontend.css">
</head>
<body>
  <div class="header">
  <img src="image/logo.png" alt="MobileShop" />
</div><br><br>
	<?php  
	if ($idAdmin < 1){ 
		header("Location: login.php");
	} 
	?>
   <ul>
    <li><a href="index.php">Hem</a></li>
    <li><a href="product.php">Produkter</a></li>
    <li><a href="allorder.php">Order</a></li>
    <li><a href="allusers.php">Användare</a></li>
    <li><a href="admins.php">Admins</a></li>
    <li><a href="orderstatus.php">Order status: <?php echo $orderStatusCount ?></a></li>
    <li><a href="messages.php">Meddelandet: <?php  echo $newMessageCount?></a></li>
    <li><a href="setting.php">Inställningar</a></li>
    <li id="navright"><a href="logout.php">Logga ut</a></li>
    <li id="navrightbg"><a href="profile.php"><?php  echo $adminInfo['Aname']?></a></li>
    </ul>     
    <br><br><label class="pagetitle">Alla produkter</label><br><br>
    <form method="post">
    <button  id="midclick"  name="addProd">Lägga till ny produkt</button><br><br>
    </form>
	<table id="alltable">
  <tr>
  	<th>Artikel nummer</th>
    <th>Titel</th>
    <th>Beskrivning</th>
    <th>Antal</th>
    <th>Pris</th>
    <th>Bild</th>
    <th></th>
    <th></th>
  </tr>
  <?php
  if ($result->num_rows > 0) {
  // output data of each row
  while($row = $result->fetch_assoc()) {
  ?>
  <tr>
    <td width="5%"><?php echo $row["prod_id"]; ?> </td>
    <td width="15%"><?php echo $row["prod_title"]; ?></td>
    <td width="40%"><?php echo $row["prod_des"]; ?></td>
    <td width="3%"><?php echo $row["prod_count"]; ?></td>
    <td width="7%"><?php echo $row["prod_price"]; ?> kr</td>
    <td width="5%"><?php echo'<img height="60" width="40" src="image/'.$row['prod_image'].'">'; ?></td>
      <form method="post">
        <td width="10%"><input type="submit" name="editprod" value="Ändra"></td>
        <input type="hidden" name="prodid" value="<?php echo $row["prod_id"];?>">
        </form>
      <form method="post">
        <td width="10%"><input type="submit" name="delprod" value="Ta bort"></td>
        <input type="hidden" name="prodid" value="<?php echo $row["prod_id"];?>">
        </form>
  </tr>

  <?php
  }
} 
  ?>
</table>
	<div class="footer">
      <div class="nav">
        <ul>
          <li><a href="index.php">Hem</a></li>
          <li><a href="product.php">Produkter</a></li>
          <li><a href="#">Om oss</a></li>
          <li><a href="#">Kontakta oss</a></li>
        </ul>
      </div>
   </div>

   <div class="footer-end">
      <p>Hemsidan skapat av: Ameer Alkadhimi, Pehr Häqqvist och Hamid Qurban - 2021</p>
   </div>
</body>
</html>