<?php
session_start();

  include("connection.php");
  include("function.php");
  $adminInfo = adminInfo($conn);
  $idAdmin = $adminInfo ['admin_id'];
  $orderStatusCount = getOrderStatusCount($conn);
  $newMessageCount = getNewMessageCountAdmin($conn);
  $getSiteSetting = getSiteSetting($conn);
  $selectOrder = mysqli_query($conn, "SELECT * FROM orders JOIN users ON orders.order_user = users.user_id WHERE orders.order_status = 0;");
  if ($_SERVER['REQUEST_METHOD'] == "POST"){
    mysqli_begin_transaction($conn);
      try{
    $prodId = $_POST['prodId'];
    if (isset($_POST['seOrder'])) {
      header("location: order.php?id=$prodId");
    }
    elseif(isset($_POST['approved'])){
      mysqli_query($conn, "UPDATE orders SET order_status = 1 WHERE order_id = $prodId");
      header("location: orderstatus.php");
    }
    elseif(isset($_POST['denied'])){
      mysqli_query($conn, "DELETE FROM orders WHERE order_id = $prodId");
      header("location: orderstatus.php");
    }
    mysqli_commit($conn);
          } catch (mysqli_sql_exception $exception) {
              mysqli_rollback($conn);
              throw $exception;
          }
    
  }
  
?>
<!DOCTYPE html>
<html>
<head>
  <title><?php echo $getSiteSetting['site_name'] ?> - Kontrollpanalen</title>
  <meta name="description" content="<?php echo $getSiteSetting['site_desc'] ?>">
  <meta name="keywords" content="<?php echo $getSiteSetting['site_meta'] ?>">
  <link rel="stylesheet" href="../frontend.css">
</head>
<body>
  <div class="header">
  <img src="image/logo.png" alt="MobileShop" />
</div><br><br>
  <?php  
  if ($idAdmin < 1){ 
    header("location: login.php");
   } else {
  ?>
  <ul>
    <li><a href="index.php">Hem</a></li>
    <li><a href="product.php">Produkter</a></li>
    <li><a href="allorder.php">Order</a></li>
    <li><a href="allusers.php">Användare</a></li>
    <li><a href="admins.php">Admins</a></li>
    <li><a href="orderstatus.php">Order status: <?php echo $orderStatusCount ?></a></li>
    <li><a href="messages.php">Meddelandet: <?php  echo $newMessageCount?></a></li>
    <li><a href="setting.php">Inställningar</a></li>
    <li id="navright"><a href="logout.php">Logga ut</a></li>
    <li id="navrightbg"><a href="profile.php"><?php  echo $adminInfo['Aname']?></a></li>
    </ul>     
    <br><br><label class="pagetitle">Alla nya order</label><br><br>
  <?php
   } 
   ?>
   <table id="alltable">
  <tr>
    <th width="5%">Order ID</th>
    <th width="20%">Beställare namn</th>
    <th width="20%">Beställare E-post</th>
    <th width="5%">Antal produkter</th>
    <th width="10%">Pris</th>
    <th width="15%">Datum och tid</th>
    <th width="25%">Välj</th>
  </tr>
  <?php
  if ($selectOrder->num_rows > 0) {
    while ($getOrder = $selectOrder->fetch_assoc()) {
      ?>
    <tr>
    <td width="5%"><?php echo $getOrder['order_id']; ?></td>
    <td width="20%"><?php echo $getOrder ['Fname']; echo " " . $getOrder ['Lname']; ?></td>
    <td width="20%"><?php echo $getOrder['user_email']; ?></td>
    <td width="5%"><?php echo $getOrder['order_prod_count']; ?></td>
    <td width="10%"><?php echo $getOrder['order_sum']; ?> kr</td>
    <td width="15%"><?php echo $getOrder['order_date']; ?></td>
    <form method="post">
    <td width="25%"><button name="seOrder">See order</button><button name="approved">Gödkänna</button><button name="denied">Neka</button></td>
    <input type="hidden" name="prodId" value="<?php echo $getOrder['order_id'];?>">
  </tr>
  </form>
 
    <?php 
    }
  }
  ?>
   </table>
   <div class="footer">
      <div class="nav">
        <ul>
          <li><a href="index.php">Hem</a></li>
          <li><a href="product.php">Produkter</a></li>
          <li><a href="#">Om oss</a></li>
          <li><a href="#">Kontakta oss</a></li>
        </ul>
      </div>
   </div>

   <div class="footer-end">
      <p>Hemsidan skapat av: Ameer Alkadhimi, Pehr Häqqvist och Hamid Qurban - 2021</p>
   </div>

</body>
</html>