<?php
error_reporting(0);
session_start();
  include("connection.php");
  include("function.php");
  $adminInfo = adminInfo($conn);
  $idAdmin = $adminInfo ['admin_id'];
  $orderStatusCount = getOrderStatusCount($conn);
  $newMessageCount = getNewMessageCountAdmin($conn);
  $getSiteSetting = getSiteSetting($conn);
$id = $_GET['id'];
$sql = mysqli_query($conn, "SELECT * from prod WHERE prod_id = '$id' limit 1"); 
$result = mysqli_fetch_assoc($sql);
if (isset($_POST['update'])) {
    if (empty($_FILES['uploadfile']['name'])) {
        $filename = $result['prod_image'];
    }
    else {
    $filename = $_FILES["uploadfile"]["name"];
    $tempname = $_FILES["uploadfile"]["tmp_name"]; 
    }
    $folder = "image/".$filename;
    $title = $_POST['title'];
    $price = $_POST['price'];
    $count = $_POST['count'];
    $des = $_POST['des'];
        if (empty($title) || empty($price) || empty($count) || empty($des)) {
            echo "Du måste fylla på alla information ";
        }
        mysqli_begin_transaction($conn);
        try{
        mysqli_query($conn, "UPDATE prod SET prod_title = '$title', prod_price = '$price', prod_count = '$count', prod_des = '$des', prod_image = '$filename' WHERE prod_id= $id");
        move_uploaded_file($tempname, $folder);
        mysqli_commit($conn);
      } catch (mysqli_sql_exception $exception) {
          mysqli_rollback($conn);
           throw $exception;
        }
        header("Location: product.php");      
}
?>

<!DOCTYPE html>
<html>
<head>
  <title><?php echo $getSiteSetting['site_name'] ?> - Kontrollpanalen</title>
  <meta name="description" content="<?php echo $getSiteSetting['site_desc'] ?>">
  <meta name="keywords" content="<?php echo $getSiteSetting['site_meta'] ?>">
  <link rel="stylesheet" href="../frontend.css">
</head>
</body>
<div class="header">
  <img src="image/logo.png" alt="MobileShop" />
</div><br><br>
<?php  
    if ($idAdmin < 1){ 
        header("Location: login.php");
     } else {
    ?>
     <ul>
    <li><a href="index.php">Hem</a></li>
    <li><a href="product.php">Produkter</a></li>
    <li><a href="allorder.php">Order</a></li>
    <li><a href="allusers.php">Användare</a></li>
    <li><a href="admins.php">Admins</a></li>
    <li><a href="orderstatus.php">Order status: <?php echo $orderStatusCount ?></a></li>
    <li><a href="messages.php">Meddelandet: <?php  echo $newMessageCount?></a></li>
    <li><a href="setting.php">Inställningar</a></li>
    <li id="navright"><a href="logout.php">Logga ut</a></li>
    <li id="navrightbg"><a href="profile.php"><?php  echo $adminInfo['Aname']?></a></li>
    </ul>
<br><br><label class="pagetitle">Ändra produkten</label><br><br>
<div class="formbox">
        <form method="POST" action="" enctype="multipart/form-data">
            <label id="fName"  for="title">Titel: </label><br>
            <input  type="text" name="title" value="<?php echo $result['prod_title'] ?>"><br><br>
            <label id="fName" for="price">Pris: </label><br>
            <input type="number" name="price" value="<?php echo $result['prod_price'] ?>"><br><br>
            <label id="fName" for="count">Antal:</label><br>
            <input type="number" name="count" value="<?php echo $result['prod_count'] ?>"><br><br>
            <label id="fName" for="des">Beskrivning: </label><br>
            <textarea id="messsageArea" name="des"><?php echo $result['prod_des'] ?></textarea><br>
            <?php echo'<img height="100" width="80" src="image/'.$result['prod_image'].'">'; ?> <br><br>
            <input type="file" name="uploadfile" value=""/><br><br>
            <input type="submit" name="update" value="Ändra produkten"><br><br> 
        </form>     
    </div>
    <?php
     } 
    ?>
    <div class="footer">
      <div class="nav">
        <ul>
          <li><a href="index.php">Hem</a></li>
          <li><a href="product.php">Produkter</a></li>
          <li><a href="#">Om oss</a></li>
          <li><a href="#">Kontakta oss</a></li>
        </ul>
      </div>
   </div>

   <div class="footer-end">
      <p>Hemsidan skapat av: Ameer Alkadhimi, Pehr Häqqvist och Hamid Qurban - 2021</p>
   </div>
</body>
</html>
