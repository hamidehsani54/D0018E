<?php
session_start();

  include("cPanel/connection.php");
  include("cPanel/function.php");
  $userInfo = userInfo($conn);
  $getCartsCount = getCartsCount($conn);
  $getSiteSetting = getSiteSetting($conn);
  $userID = $userInfo['user_id'];
  $newMessagesCount = getNewMessageCountUser($conn,$userID);
  //hämtar order för specifik användare
  $selectOrder = mysqli_query($conn, "SELECT * from orders WHERE order_user = '$userID'");
  if ($_SERVER['REQUEST_METHOD'] == "POST"){
    $prodId = $_POST['prodId'];
    //om man har klickad på "seOrder"
    if (isset($_POST['seOrder'])) {
      header("location: order.php?id=$prodId");
    }
  }
  
?>
<!DOCTYPE html>
<html>
<head>
  <title><?php echo $getSiteSetting['site_name'] ?> - Historik</title>
  <meta name="description" content="<?php echo $getSiteSetting['site_desc'] ?>">
  <meta name="keywords" content="<?php echo $getSiteSetting['site_meta'] ?>">
  <link rel="stylesheet" href="frontend.css">
</head>
<body>
  <div class="header">
  <img src="cPanel/image/logo.png" alt="<?php echo $getSiteSetting['site_name'] ?>" />
  </div><br><br>
  <?php  
  if ($userID < 1){ 
    header("location: login.php");
   } else {
  ?>
<ul>
  <li><a href="index.php">Hem</a></li>
  <li><a href="product.php">Produkter</a></li>
  <li><a href="history.php">Historik</a></li>
  <li><a href="sendmessages.php">Kontakta admin</a></li>
  <li><a href="messages.php">Meddelanden: <?php  echo $newMessagesCount?></a></li>
  <li id="navright"><a href="logout.php">Logga ut</a></li>
  <li id="navrightbg"><a href="cart.php">Varukorgen: <?php  echo $getCartsCount?></a></li>
  <li id="navrightbg"><a href="profile.php"><?php  echo $userInfo['Fname']?></a></li>
  </ul>
  <br><br><label class="pagetitle">Meddelanden</label><br><br>
  <?php
   } 
   ?>
   
  <?php
  if ($selectOrder->num_rows > 0) {
    ?>
    <table id="alltable">
  <tr>
    <th>Order ID</th>
    <th>Antal produkter</th>
    <th>Pris</th>
    <th>Datum och tid</th>
    <th></th>
  </tr>
    <?php
    while ($getOrder = $selectOrder->fetch_assoc()) {
      ?>
    <tr>
    <td><?php echo $getOrder['order_id']; ?></td>
    <td><?php echo $getOrder['order_prod_count']; ?></td>
    <td><?php echo $getOrder['order_sum']; ?> kr</td>
    <td><?php echo $getOrder['order_date']; ?></td>
    <form method="post">
    <td><button id="seorder" name="seOrder">See order</button></td>
    <input type="hidden" name="prodId" value="<?php echo $getOrder['order_id'];?>">
  </tr>
  </form>
 
    <?php 
    }
  }
  else{
    echo '<p id="boldtext">Det finns inga gamla order att visa</p>';
  }
  ?>
   </table>
   <div class="footer">
      <div class="nav">
        <ul>
          <li><a href="#">Om oss</a></li>
          <li><a href="#">Kontakta oss</a></li>
        </ul>
      </div>
   </div>

   <div class="footer-end">
      <p>Hemsidan skapat av: Ameer Alkadhimi, Pehr Häqqvist och Hamid Qurban - 2021</p>
   </div>


</body>
</html>