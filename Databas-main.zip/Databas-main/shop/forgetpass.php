<?php
	session_start();
	include("cPanel/connection.php");
	include("cPanel/function.php");
	$getSiteSetting = getSiteSetting($conn);
	if ($_SERVER['REQUEST_METHOD'] == "POST"){
		$email = $_POST['email'];

		//om inga information är infyllda 
		if (empty($email)) {
			header("Location: forgetpass.php?error=emptyfields");	
		} 
		//om emailet skrivits på rätt sätt
		elseif(!filter_var($email, FILTER_VALIDATE_EMAIL)) {
			header("Location: forgetpass.php?error=invalidemail");	
		} 

		else {
			$email = $_POST['email'];
			//kontrollerar om mejlet finns i databas
			$query = "SELECT * from users WHERE user_email = '$email'";
			$result = mysqli_query($conn, $query);
			$getpassword = mysqli_fetch_assoc($result);
			//ett nytt lösenord skickas via mejlet
			if($getpassword){
				$lösen = $getpassword['user_password'];
				echo "Lösenorder har sänds till email";
				$to = $getpassword['user_email'];
				$subject = "Nytt lösenord";
				$txt = "Här kommer ditt nya lösenord" .$lösen;
				$headers = "From: webmaster@example.com" . "\r\n" .
				"CC: somebodyelse@example.com";
				mail($to,$subject,$txt,$headers);

			}
			else {
				echo ("Emailen finns inte registrerad");
			}
		}
	} 


?>

<!DOCTYPE html>
<html>
<head>
	<title><?php echo $getSiteSetting['site_name'] ?></title>
  <meta name="description" content="<?php echo $getSiteSetting['site_desc'] ?>">
  <meta name="keywords" content="<?php echo $getSiteSetting['site_meta'] ?>">
  <link rel="stylesheet" href="frontend.css">
</head>
<body>
	<div class="header">
  <img src="cPanel/image/logo.png" alt="MobileShop" />
</div><br><br>
  <ul>
  <li><a href="index.php">Hem</a></li>
  <li><a href="product.php">Produkter</a></li>
  <li><a href="login.php">Logga in</a></li>
  <li><a href="signup.php">Registrera</a></li>
  </ul>
  <br><br><label class="pagetitle">Återställ lösenord</label><br><br>
	<div class="signbox">
		<form method="post">
			<label id="fName" for="email">Email:</label><br>
			<input type="text" name="email" placeholder="Email..."><br>
			<input id="sub" type="submit" value="Skicka">
		</form>		
	</div>
	<div class="footer">
      <div class="nav">
        <ul>
          <li><a href="#">Om oss</a></li>
          <li><a href="#">Kontakta oss</a></li>
        </ul>
      </div>
   </div>

   <div class="footer-end">
      <p>Hemsidan skapat av: Ameer Alkadhimi, Pehr Häqqvist och Hamid Qurban - 2021</p>
   </div>
</body>
</html>
