<?php
session_start();

  include("cPanel/connection.php");
  include("cPanel/function.php");
  $userInfo = userInfo($conn);
  $idUser = $userInfo ['user_id'];
  $newMessagesCount = getNewMessageCountUser($conn,$idUser);
  $getCartsCount = getCartsCount($conn);
  $getSiteSetting = getSiteSetting($conn);
  $orderID;
  $orderDate;
  $prodID;
  $orderSum;
  $countSum;
  mysqli_begin_transaction($conn);
  try{
    // hämtar senaste order från databasen
      $getLastRow = mysqli_query($conn, "SELECT order_id AS last_row FROM orders WHERE order_user = $idUser ORDER BY order_id DESC LIMIT 1");
      $lastRow = mysqli_fetch_assoc($getLastRow);
      $lastOrder = $lastRow['last_row'];
      //hämtar produkter för senaste order från databasen
      $orderConnection = mysqli_query($conn,"SELECT * FROM ordersprod JOIN orders ON orders.order_id = ordersprod.o_order_id WHERE ordersprod.o_order_id = $lastOrder");
      mysqli_commit($conn);
      //annars gör en rollback
      } catch (mysqli_sql_exception $exception) {
          mysqli_rollback($conn);
           throw $exception;
        }
  
?>
<!DOCTYPE html>
<html>
<head>
  <title><?php echo $getSiteSetting['site_name'] ?></title>
  <meta name="description" content="<?php echo $getSiteSetting['site_desc'] ?>">
  <meta name="keywords" content="<?php echo $getSiteSetting['site_meta'] ?>">
  <link rel="stylesheet" href="frontend.css">
</head>
<body>
  <div class="header">
  <img src="cPanel/image/logo.png" alt="MobileShop" />
</div><br><br>
  <?php  
  if ($idUser < 1){ 
    header("location: login.php");
   } else {
  ?>
  <ul>
  <li><a href="index.php">Hem</a></li>
  <li><a href="product.php">Produkter</a></li>
  <li><a href="history.php">Historik</a></li>
  <li><a href="sendmessages.php">Kontakta admin</a></li>
  <li><a href="messages.php">Meddelanden: <?php  echo $newMessagesCount?></a></li>
  <li id="navright"><a href="logout.php">Logga ut</a></li>
  <li id="navrightbg"><a href="cart.php">Varukorgen: <?php  echo $getCartsCount?></a></li>
  <li id="navrightbg"><a href="profile.php"><?php  echo $userInfo['Fname']?></a></li>
  </ul>
  <?php
   } 
   ?>
   <br><br><label class="pagetitle">Bekräftelse</label><br><br>
   <h2>Tack för din beställning. Beställningen är mottaget</h2>
   <table id="alltable">
  <tr>
    <th width="10%"></th>
    <th width="40%">Produkt</th>
    <th width="10%">Artikelnummer</th>
    <th width="15%">Pris</th>
    <th width="10%">Antal</th>
    <th width="15%">Summa</th>
  </tr>
  <?php

  if ($orderConnection->num_rows > 0) {
    while ($orderDetails = $orderConnection->fetch_assoc()) {
      $orderID = $orderDetails['o_order_id'];
      $orderDate = $orderDetails['order_date'];
      $prodID = $orderDetails['product_id'];
      $orderSum = $orderDetails['order_sum'];
      $countSum = $orderDetails['order_prod_count'];
      $prodConn = mysqli_query($conn,"SELECT * from prod WHERE prod_id = '$prodID'");
      $getProd = mysqli_fetch_assoc($prodConn);

      ?>

    <tr>
    <td width="10%"><?php echo'<img height="50" width="40" src="cPanel/image/'.$getProd ['prod_image'].'">' ?></td>
    <td width="40%"><?php echo $getProd ['prod_title'] ?></td>
    <td width="10%"><?php echo $prodID?></td>
    <td width="15%"><?php echo $orderDetails['o_prod_price'] ?> kr</td>
    <td width="10%"><?php echo $orderDetails['o_count'] ?></td>
    <td width="15%"><?php echo $tot = $orderDetails['o_prod_price'] * $orderDetails['o_count']; ?> kr</td>
  </tr>
    <?php 
    }
  }
      
  ?>
  <tr>
    <td width="10%"></td>
    <td width="40%"></td>
    <td width="10%"></td>
    <td width="15%"></td>
    <td id="boldtext" width="10%">Antal produkter</td>
    <td id="boldtext" width="15%">Total summa</td>
  </tr>
  <tr>
    <td width="10%"></td>
    <td width="40%"></td>
    <td width="10%"></td>
    <td width="15%"></td>
    <td id="boldtext" width="10%"><?php echo $countSum ?> kr</td>
    <td id="boldtext" width="15%"><?php echo $orderSum?> kr</td>
  </tr>
  <h2>Order # <?php echo $orderID; ?></h2>
   <label>Datum och tid : <?php echo $orderDate ?></label><br><br>
  </table>
<div class="footer">
      <div class="nav">
        <ul>

          <li><a href="#">Om oss</a></li>
          <li><a href="#">Kontakta oss</a></li>
        </ul>
      </div>
   </div>

   <div class="footer-end">
      <p>Hemsidan skapat av: Ameer Alkadhimi, Pehr Häqqvist och Hamid Qurban - 2021</p>
   </div>
</body>
</html>