<?php
session_start();

  include("cPanel/connection.php");
  include("cPanel/function.php");

  //hämtar användarens info
  $userInfo = userInfo($conn);
    //visar antal produkter i varukoregen
  $getCartsCount = getCartsCount($conn);
    //hämtar hemsidansinställningar
  $getSiteSetting = getSiteSetting($conn);
  $idUser = $userInfo ['user_id'];
    //visar nya meddelandet
  $newMessagesCount = getNewMessageCountUser($conn,$idUser);
  $tot = 0;
  //hämtar varukorgens information från databas
  $cartConnection = mysqli_query($conn,"SELECT * from carts WHERE c_user_id = '$idUser'");
  //om kunden har clickat på köp då varan läggs till i varukorgen 
  if ($_SERVER['REQUEST_METHOD'] == "POST"){
      //om kunden har klickad på tabort knappen
      if (isset($_POST['del'])) {
        $cartid = $_POST['cartid'];
        header("location: cPanel/deleteCart.php?id=$cartid");
     }
     //om kunden har klickad på betala
     if (isset($_POST['checkbuy'])) {
        header("location: checkout.php");
     }
  }
?>
<!DOCTYPE html>
<html>
<head>
  <title><?php echo $getSiteSetting['site_name'] ?> - Varukorgen</title>
  <meta name="description" content="<?php echo $getSiteSetting['site_desc'] ?>">
  <meta name="keywords" content="<?php echo $getSiteSetting['site_meta'] ?>">
  <link rel="stylesheet" href="frontend.css">
</head>
<body>
  <div class="header">
 <img src="cPanel/image/logo.png" alt="<?php echo $getSiteSetting['site_name'] ?>" />
</div><br><br>
  <?php  
  //om användaren inte är inloggad
  if ($idUser < 1){ 
    header("location: login.php");
   } else {
  ?>
  <!-- om användaren är inloggad-->
  <ul>
  <li><a href="index.php">Hem</a></li>
  <li><a href="product.php">Produkter</a></li>
  <li><a href="history.php">Historik</a></li>
  <li><a href="sendmessages.php">Kontakta admin</a></li>
  <li><a href="messages.php">Meddelanden: <?php  echo $newMessagesCount?></a></li>
  <li id="navright"><a href="logout.php">Logga ut</a></li>
  <li id="navrightbg"><a href="cart.php">Varukorgen: <?php  echo $getCartsCount?></a></li>
  <li id="navrightbg"><a href="profile.php"><?php  echo $userInfo['Fname']?></a></li>
  </ul>
  <br><br><label class="pagetitle">Varukorgen</label><br><br>
  <?php
   } 
   //om produkt finns i varukorgen då visas dem
  if ($cartConnection->num_rows > 0) {
    ?>
    <table id="alltable">
  <tr>
    <th></th>
    <th>Produkt</th>
    <th>Antal</th>
    <th>Pris</th>
    <th>Total</th>
    <th>Ändring</th>
  </tr>
    <?php
    while ($row = $cartConnection->fetch_assoc()) {
  ?>
  <tr>
    <td><?php echo'<img height="100" width="80" src="cPanel/image/'.$row['c_prod_image'].'">'?></td>
    <td><?php echo $row['c_prod_titel'];?></td>
    <td><?php echo $row['cart_count']; ?></td>
    <td><?php echo $row['c_prod_price']; ?> Kr</td>
    <td><?php $priceP = $row['c_prod_price']; $totalC = $row['cart_count']; $totalPrice = $priceP * $totalC; $tot = $tot + $totalPrice; echo $totalPrice; ?> Kr</td>
    <form method="post">
    <td><input type="submit" name="del" value="Ta bort"></td>
    <input type="hidden" name="cartid" value="<?php echo $row["cart_id"];?>">
    </form>
  </tr>
  <?php
  }
  ?>

  <!-- summan och betalnings funktionen/knappen-->
  <tr>
    <td></td>
    <td></td>
    <td></td>
    <td id="boldtext">Summa:</td>
    <td id="boldtext"><?php echo $tot; ?> Kr</td>
    <form method="post">
      <td><input type="submit" name="checkbuy" value="Betala"></td>
    </form>
  </tr>
  </table>
  <?php

  //i fall finns inga  produkter att visa
} else {
  echo '<p id="boldtext">Inga produkter i varukorgen</p>';
}
  ?>
  <div class="footer">
      <div class="nav">
        <ul>
          <li><a href="#">Om oss</a></li>
          <li><a href="#">Kontakta oss</a></li>
        </ul>
      </div>
   </div>

   <div class="footer-end">
      <p>Hemsidan skapat av: Ameer Alkadhimi, Pehr Häqqvist och Hamid Qurban - 2021</p>
   </div>
</body>
</html>