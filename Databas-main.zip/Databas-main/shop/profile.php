<?php
session_start();

	include("cPanel/connection.php");
	include("cPanel/function.php");
	$userInfo = userInfo($conn);
	$idUser = $userInfo ['user_id'];
  	$newMessagesCount = getNewMessageCountUser($conn,$idUser);
	$getCartsCount = getCartsCount($conn);
	$getSiteSetting = getSiteSetting($conn);
  	if($idUser < 1) {
      header("location: login.php");
    }
	if ($_SERVER['REQUEST_METHOD'] == "POST"){
		mysqli_begin_transaction($conn);

		//profiländring
		try{

			if (isset($_POST['changeForName'])) {
				$forName = $_POST['forName'];
				//updatera ändringen i databasen
				mysqli_query($conn, "UPDATE users SET Fname = '$forName' WHERE user_id = $idUser");
	      		header("location: profile.php");
			}
			elseif (isset($_POST['changeLastName'])) {
				$lastName = $_POST['lastName'];
				mysqli_query($conn, "UPDATE users SET Lname = '$lastName' WHERE user_id = $idUser");
	      		header("location: profile.php");
			}
			elseif (isset($_POST['email'])) {
				$email = $_POST['changeEmail'];
				mysqli_query($conn, "UPDATE users SET user_email = '$email' WHERE user_id = $idUser");
	      		header("location: profile.php");
			}
			elseif (isset($_POST['changePassword'])) {
				$password = $_POST['passwordvalue'];
				mysqli_query($conn, "UPDATE users SET user_password = '$password' WHERE user_id = $idUser");
	      		header("location: profile.php");
			}
			mysqli_commit($conn);
	      		} catch (mysqli_sql_exception $exception) {
	          		mysqli_rollback($conn);
	           		throw $exception;
	        	}

	}

	
?>
<!DOCTYPE html>
<html>
<head>
	<title><?php echo $getSiteSetting['site_name'] ?> - Mina sidor</title>
  <meta name="description" content="<?php echo $getSiteSetting['site_desc'] ?>">
  <meta name="keywords" content="<?php echo $getSiteSetting['site_meta'] ?>">
  <link rel="stylesheet" href="frontend.css">
</head>
<body>
	<div class="header">
  <img src="cPanel/image/logo.png" alt="<?php echo $getSiteSetting['site_name'] ?>" />
  </div><br><br>
	<?php  
	if ($idUser < 1){ 
		header("Location: login.php");
	}
	else{
	?>
	<ul>
  <li><a href="index.php">Hem</a></li>
  <li><a href="product.php">Produkter</a></li>
  <li><a href="history.php">Historik</a></li>
  <li><a href="sendmessages.php">Kontakta admin</a></li>
  <li><a href="messages.php">Meddelanden: <?php  echo $newMessagesCount?></a></li>
  <li id="navright"><a href="logout.php">Logga ut</a></li>
  <li id="navrightbg"><a href="cart.php">Varukorgen: <?php  echo $getCartsCount?></a></li>
  <li id="navrightbg"><a href="profile.php"><?php  echo $userInfo['Fname']?></a></li>
  </ul>
	<br><br><label class="pagetitle">Mina sidor</label><br><br>
	<br><br>
	<div class="formbox">
	<form method="post">
	<label id="fName">Förnamn:</label><br>
	<input type="text" name="forName" value="<?php echo $userInfo ['Fname'] ?>">
	<input id="sub" type="submit" name="changeForName" value="Ändra"><br><br>
	<label id="fName">Efternamn: </label><br>
	<input type="text" name="lastName" value="<?php echo $userInfo ['Lname'] ?>">
	<input id="sub" type="submit" name="changeLastName" value="Ändra"><br><br>
	<label id="fName">E-post: </label><br>
	<input type="text" name="email" value="<?php echo $userInfo ['user_email'] ?>">
	<input id="sub" type="submit" name="changeEmail" value="Ändra"><br><br>
	<label id="fName">Lösenord: </label><br>
	<input type="password" name="passwordvalue" value="*********************">
	<input id="sub" type="submit" name="changePassword" value="Ändra"><br><br>
	</form>
	</div>
	</table>
	<?php
}
?>
   <div class="footer">
      <div class="nav">
        <ul>

          <li><a href="#">Om oss</a></li>
          <li><a href="#">Kontakta oss</a></li>
        </ul>
      </div>
   </div>

   <div class="footer-end">
      <p>Hemsidan skapat av: Ameer Alkadhimi, Pehr Häqqvist och Hamid Qurban - 2021</p>
   </div>
</body>
</html>