<?php
session_start();

  include("cPanel/connection.php");
  include("cPanel/function.php");
  $userInfo = userInfo($conn);
  $userID = $userInfo['user_id'];
  $newMessagesCount = getNewMessageCountUser($conn,$userID);
  $getSiteSetting = getSiteSetting($conn);
  $getCartsCount = getCartsCount($conn);
  $userFname = $userInfo['Fname'];
  $userLname = $userInfo['Lname'];
  //fånga produkt-id från länken
  $id = $_GET['id'];

  //hämtar produkt information
  $orderConnection = mysqli_query($conn,"SELECT * FROM prod where prod_id = $id");
  $prodInfo = mysqli_fetch_assoc($orderConnection);
  //hamta kommentarer för en specifik produkt
  $commentConnection = mysqli_query($conn,"SELECT * FROM comments where comment_prod = $id");
  if ($_SERVER['REQUEST_METHOD'] == "POST"){
    //om "comment" knappen är klickad men saknar information
    if (isset($_POST['comment'])) {
      $commentText = $_POST['commentText'];
        if (strlen($commentText) == 0) {
          echo '<p id="redmsg">Du måste skriva ett kommentar</p>';
      }
      //väljer antal stjärnor
      else{
        $star = $_POST['star'];
        mysqli_begin_transaction($conn);
        try{
          //spara kommentarsinformation i databas
          mysqli_query($conn, "INSERT into comments (comment_prod,comment_user_id,comment_user_Fname,comment_user_Lname,comment_rating,comment_text ) values ('$id','$userID','$userFname','$userLname','$star','$commentText')");
          mysqli_commit($conn);
        } catch (mysqli_sql_exception $exception) {
            mysqli_rollback($conn);
             throw $exception;
          }
      
        header("location: prodview.php?id=$id");
    }
  } 
    //om "buyClicked" är klickad då läggs den i varukoregen
    elseif(isset($_POST['buyClick'])){
      $prodid = $_POST['prodid'];
    header("location: cPanel/addtocart.php?id=$prodid&u=$userID");

    }
   }
    
  
    
?>
<!DOCTYPE html>
<html>
<head>
  <title><?php echo $getSiteSetting['site_name'] . ' ' . $prodInfo['prod_title'] ;?></title>
  <meta name="description" content="<?php echo $getSiteSetting['site_desc'] ?>">
  <meta name="keywords" content="<?php echo $getSiteSetting['site_meta'] ?>">
  <link rel="stylesheet" href="frontend.css">
</head>
<body>
  <div class="header">
  <img src="cPanel/image/logo.png" alt="MobileShop" />
</div><br><br>
  <?php  
  if ($userID < 1){  
  ?> 
  <ul>
  <li><a href="index.php">Hem</a></li>
  <li><a href="product.php">Produkter</a></li>
  <li><a href="login.php">Logga in</a></li>
  <li><a href="signup.php">Registera</a></li>
  </ul>
  <?php
   } else {
  ?>
<ul>
  <li><a href="index.php">Hem</a></li>
  <li><a href="product.php">Produkter</a></li>
  <li><a href="history.php">Historik</a></li>
  <li><a href="sendmessages.php">Kontakta admin</a></li>
  <li><a href="messages.php">Meddelanden: <?php  echo $newMessagesCount?></a></li>
  <li id="navright"><a href="logout.php">Logga ut</a></li>
  <li id="navrightbg"><a href="cart.php">Varukorgen: <?php  echo $getCartsCount?></a></li>
  <li id="navrightbg"><a href="profile.php"><?php  echo $userInfo['Fname']?></a></li>
  </ul>
  <?php
   } 
   ?>
   <img class="prodImage" src="cPanel/image/<?php echo $prodInfo["prod_image"];?>">
   <h2 class="prodTitle"><?php echo $prodInfo['prod_title']?></h2>
   <h2 class="prodPrice"><?php echo $prodInfo['prod_price']?> kr</h2>
   <?php 
  if ($prodInfo["prod_count"] == 0) {
    echo '<label class="prodCount">Antal i lager: Slut i lager</label> <br>';
    echo '<p class="prodDesc">Beskrivning: ' . $prodInfo['prod_des'] . '</p>';
  }
  else{
    echo '<label class="prodCount" >Antal i lager: ' . $prodInfo['prod_count'] .  ' st</label><br>';
    echo '<p class="prodDesc" >Beskrivning: ' . $prodInfo['prod_des'] . '</p><br>';
    ?>
    <form method="post">
      <input id="bCl" type="submit" name="buyClick" value="KÖP <?php echo strtoupper($prodInfo['prod_title'])?> ">
      <input type="hidden" name="prodid" value="<?php echo $prodInfo["prod_id"];?>">
    </form>
    <?php
  }
  ?>
   
   <h3 class="recens">Recensioner</h3>
   <?php 
    if (isset($_SESSION['user_id'])){
      ?>
   <form method="post">
   <div class="rating">
  <input id="radio1" type="radio" name="star" value="5" class="star" />
  <label for="radio1">&#9733;</label>
  <input id="radio2" type="radio" name="star" value="4" class="star" />
  <label for="radio2">&#9733;</label>
  <input id="radio3" type="radio" name="star" value="3" class="star" />
  <label for="radio3">&#9733;</label>
  <input id="radio4" type="radio" name="star" value="2" class="star" />
  <label for="radio4">&#9733;</label>
  <input id="radio5" type="radio" name="star" value="1" class="star" />
  <label for="radio5">&#9733;</label>
</div>
  <label>Skriv ett kommentar: </label><br>
   <textarea id="commentArea" name="commentText"></textarea><br>
   <input id="commentsend" type="submit" name="comment" value="Skicka"> <br><br>
   </form>
   <?php 
 }
   if ($commentConnection->num_rows > 0) {
    while ($row = $commentConnection->fetch_assoc()) {
      echo '<div class="commentBox">';
      $forName = strtoupper($row['comment_user_Fname']);
      $afterName = strtoupper($row['comment_user_Lname']);
       echo ' <label>' .$forName . ' ' . $afterName. ':    </label>';
       for ($i=0; $i < $row['comment_rating'] ; $i++) { 
         echo '<label style="font-size: 20px; color: orange;">&#9733;</label>';
       }
       echo '<br><br>'. $row['comment_text'] . '<br>';
       echo '</div>';
    }
    
  }

   ?>
   <div class="footer">
      <div class="nav">
        <ul>

          <li><a href="#">Om oss</a></li>
          <li><a href="#">Kontakta oss</a></li>
        </ul>
      </div>
   </div>

   <div class="footer-end">
      <p>Hemsidan skapat av: Ameer Alkadhimi, Pehr Häqqvist och Hamid Qurban - 2021</p>
   </div>

</body>
</html>