<?php
session_start();
  include("cPanel/connection.php");
  include("cPanel/function.php");
  $userInfo = userInfo($conn);
  $userID = $userInfo['user_id'];
  $newMessagesCount = getNewMessageCountUser($conn,$userID);
  $getCartsCount = getCartsCount($conn);
  $getSiteSetting = getSiteSetting($conn);
  $result = mysqli_query($conn,"SELECT * FROM prod");
  //om "buyClick" är klickad
   if ($_SERVER['REQUEST_METHOD'] == "POST" && isset($_POST['buyClick'])){
    //om man är inte inloggad så kan man inte köpa 
    if ($userID < 1) {
      header("location: login.php");
    }
    //Annars läggs produkten i varukorgen
    else {
    $prodid = $_POST['prodid'];
    header("location: cPanel/addtocart.php?id=$prodid&u=$userID");
    }
  }
?>
<!DOCTYPE html>
<html>
<head>
  <title><?php echo $getSiteSetting['site_name'] ?> - Produkter</title>
  <meta name="description" content="<?php echo $getSiteSetting['site_desc'] ?>">
  <meta name="keywords" content="<?php echo $getSiteSetting['site_meta'] ?>">
  <link rel="stylesheet" href="frontend.css">
</head>
<body>
  <div class="header">
  <img src="cPanel/image/logo.png" alt="MobileShop" />
</div><br><br>
  <?php  
  if ($userID < 1){ 
  ?>
  <ul>
    <li><a href="index.php">Hem</a></li>
  <li><a href="product.php">Produkter</a></li>
  <li><a href="login.php">Logga in</a></li>
  <li><a href="signup.php">Registera</a></li>
  </ul>
  <?php 
} else {
  ?>
  <ul>
  <li><a href="index.php">Hem</a></li>
  <li><a href="product.php">Produkter</a></li>
  <li><a href="history.php">Historik</a></li>
  <li><a href="sendmessages.php">Kontakta admin</a></li>
  <li><a href="messages.php">Meddelanden: <?php  echo $newMessagesCount?></a></li>
  <li id="navright"><a href="logout.php">Logga ut</a></li>
  <li id="navrightbg"><a href="cart.php">Varukorgen: <?php  echo $getCartsCount?></a></li>
  <li id="navrightbg"><a href="profile.php"><?php  echo $userInfo['Fname']?></a></li>
  </ul>
  <?php
   } 
  ?>
  <br><br><label class="pagetitle">Produkter</label><br><br>
  <?php
  if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
  ?>
    <div class="card">
  <a href="prodview.php?id=<?php echo $row["prod_id"];?>"><img src="cPanel/image/<?php echo $row["prod_image"];?>"></a>
  <h2><a href="prodview.php?id=<?php echo $row["prod_id"];?>"><?php echo $row["prod_title"];?></a></h2>
  <p class="price"><?php echo $row["prod_price"];?> kr</p>
  <?php 
  if ($row["prod_count"] == 0) {
    echo '<p><button>Slut i lager</button></p>';
  }
  else{
    ?>
    <p>Antal i lager <?php echo $row["prod_count"];?></p>
    <form method="post">
      <input type="submit" name="buyClick" value="KÖP">
      <input type="hidden" name="prodid" value="<?php echo $row["prod_id"];?>">
    </form>
    <?php
  }
  ?>
  </div>
  <?php
  }
} 
  ?>
  <div class="footer">
      <div class="nav">
        <ul>

          <li><a href="#">Om oss</a></li>
          <li><a href="#">Kontakta oss</a></li>
        </ul>
      </div>
   </div>

   <div class="footer-end">
      <p>Hemsidan skapat av: Ameer Alkadhimi, Pehr Häqqvist och Hamid Qurban - 2021</p>
   </div>
  
</body>
</html>