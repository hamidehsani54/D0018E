<?php
	session_start();
	include("cPanel/connection.php");
	include("cPanel/function.php");
	$getSiteSetting = getSiteSetting($conn);
	if ($_SERVER['REQUEST_METHOD'] == "POST"){
		$forName = $_POST['forName'];
		$lastName = $_POST['lastName'];
		$email = $_POST['email'];
		$password = $_POST['passwordvalue'];
		if (empty($forName) || empty($lastName) || empty($email) || empty($password)){
			echo "Du måste fylla på alla information ";
		}
		else {
			mysqli_begin_transaction($conn);
			try{
			mysqli_query($conn, "INSERT into users (Fname,Lname,user_password,user_email) values ('$forName','$lastName','$password','$email')");
			echo "Ditt konto är skapat";
			mysqli_commit($conn);
			} catch (mysqli_sql_exception $exception) {
    			mysqli_rollback($conn);
   				 throw $exception;
				}
		}
	}
?>
<!DOCTYPE html>
<html>
<head>
	<title><?php echo $getSiteSetting['site_name'] ?> - Registera</title>
  <meta name="description" content="<?php echo $getSiteSetting['site_desc'] ?>">
  <meta name="keywords" content="<?php echo $getSiteSetting['site_meta'] ?>">
  <link rel="stylesheet" href="frontend.css">
</head>
<body>
	<div class="header">
  <img src="cPanel/image/logo.png" alt="MobileShop" />
</div><br><br>
	<?php  
	if (isset($_SESSION['user_id'])){ 
		header("Location: index.php");
	 } else {
	?>
  <ul>
  	<li><a href="index.php">Hem</a></li>
  <li><a href="product.php">Produkter</a></li>
  <li><a href="login.php">Logga in</a></li>
  </ul>
  <br><br><label class="pagetitle">Registrera</label><br><br>
	<div class="signbox">
		<form method="post">
			<input type="text" placeholder="Förnamn" name="forName"><br><br>
			<input type="text" placeholder="Efternamn" name="lastName"><br><br>
			<input type="email" placeholder="E-post" name="email"><br><br>
			<input type="password" placeholder="Lösenord" name="passwordvalue"><br><br>
			<input id="sub" type="submit" value="Registrera"><br><br>
		</form>		
	</div>
	<?php
	 } 
	?>
	<div class="footer">
      <div class="nav">
        <ul>

          <li><a href="#">Om oss</a></li>
          <li><a href="#">Kontakta oss</a></li>
        </ul>
      </div>
   </div>

   <div class="footer-end">
      <p>Hemsidan skapat av: Ameer Alkadhimi, Pehr Häqqvist och Hamid Qurban - 2021</p>
   </div>
</body>
</html>