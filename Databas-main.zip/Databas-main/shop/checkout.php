<?php
session_start();

  include("cPanel/connection.php");
  include("cPanel/function.php");
    //hämtar användarens info
  $userInfo = userInfo($conn);
  //visar antal produkter i varukoregen
  $getCartsCount = getCartsCount($conn);
  //hämtar hemsidansinställningar
  $getSiteSetting = getSiteSetting($conn);
  $idUser = $userInfo ['user_id'];
  //visar nya meddelandet
  $newMessagesCount = getNewMessageCountUser($conn,$idUser);
  $tot = 0;
  $ch = 0;
  //visar antal produkter i varukoregen
  $cartConnection = mysqli_query($conn,"SELECT * from carts WHERE c_user_id = '$idUser'");
  $totCartCount = 0;
  $currentOrderID;
  if ($_SERVER['REQUEST_METHOD'] == "POST"){
  //om kuden har klickad på betala då sparas betalningsinformation i olika variabel. 
  $buyTotal = $_POST['totSum'];
  $totinput = $_POST['totinput'];
  $totcount = $_POST['totcount'];
  //kollar om man har betalat rätt summa
    if ($buyTotal == $totinput) {
      //kollar om det finns produkter i varukorgen
      if ($cartConnection->num_rows > 0) {
        while ($row = $cartConnection->fetch_assoc()) {
          $prodID = $row['c_prod_id'];
          $cc = $row['cart_count']; 
          //hämtar produktsinformation från databas
          $prodConnection = mysqli_query($conn,"SELECT * from prod WHERE prod_id = '$prodID'");
          $prodInfo = mysqli_fetch_assoc($prodConnection);
          //om antal produkter inte finns i lager
          if ($cc > $prodInfo['prod_count']) {
            echo '<p id="redmsg">Antal produkter ' . $row['c_prod_titel'] . ' i lager räcker inte till för att klargöra köpet. Det finns endast '. $prodInfo['prod_count'] .' st kvar i lager</p>';
            $ch++;
          }
        }
      }
      //om antal produkter finns i lager
      if ($ch == 0) {
        //startas en transaction
        mysqli_begin_transaction($conn);
      try{
        //skapa order, lägga till antal produkter från varukoren till order
        mysqli_query($conn, "INSERT INTO orders (order_user,order_sum,order_prod_count,order_status) VALUES ('$idUser','$buyTotal','$totcount',0)");
        $newCartConnection = mysqli_query($conn,"SELECT * from carts WHERE c_user_id = '$idUser'");
        if ($newCartConnection->num_rows > 0) {
           while ($row = $newCartConnection->fetch_assoc()) {
            //spara produktsinformation i olika variabler
            $prodID = $row['c_prod_id'];
            $prodPrice = $row['c_prod_price'];
            $prodCount = $row['cart_count']; 
            //hämtar sista raden i orderstabellen for specifik användaren
            $getLastRow = mysqli_query($conn, "SELECT * FROM `orders` WHERE order_user = $idUser ORDER BY `orders`.`order_id` DESC LIMIT 1");
            $lastO = mysqli_fetch_assoc($getLastRow);
            $lastOrder = $lastO['order_id'];
            //lägga till produkter från varukoren till orderproduktstabllen
           mysqli_query($conn, "INSERT INTO ordersprod (o_order_id, person_id, product_id, o_prod_price, o_count) VALUES ('$lastOrder', '$idUser', $prodID, '$prodPrice', '$prodCount')");
            $prodConnection = mysqli_query($conn,"SELECT * from prod WHERE prod_id = $prodID");
            $prodInfo = mysqli_fetch_assoc($prodConnection);


            //minskar antal produkter från lagret
            $prodCountLeft = $prodInfo['prod_count'];
            $prodCountLeft = $prodCountLeft - $prodCount;

            //updatera antal produkter i databasen
            mysqli_query($conn, "UPDATE prod SET prod_count = '$prodCountLeft' WHERE prod_id= '$prodID'");
            //toma varukorgen
            mysqli_query($conn, "DELETE FROM carts WHERE c_user_id = '$idUser'");
           }
         }
         //gör en rollback om något fel inträffade
         mysqli_commit($conn);
          } catch (mysqli_sql_exception $exception) {
              mysqli_rollback($conn);
              throw $exception;
          }
         header("location: orderconfirm.php");
      }
        
      } 
  }

?>
<!DOCTYPE html>
<html>
<head>
  <title><?php echo $getSiteSetting['site_name'] ?></title>
  <meta name="description" content="<?php echo $getSiteSetting['site_desc'] ?>">
  <meta name="keywords" content="<?php echo $getSiteSetting['site_meta'] ?>">
  <link rel="stylesheet" href="frontend.css">
</head>
<body>
  <div class="header">
 <img src="cPanel/image/logo.png" alt="<?php echo $getSiteSetting['site_name'] ?>" />
</div><br><br>
  
  <?php  
  //om kunden är inte inloggad
  if ($idUser < 1){ 
    header("location: login.php");
   } 
  else {
  ?>
  <!-- användaren är inloggad-->
    <ul>
      <li><a href="index.php">Hem</a></li>
      <li><a href="product.php">Produkter</a></li>
      <li><a href="history.php">Historik</a></li>
      <li><a href="sendmessages.php">Kontakta admin</a></li>
      <li><a href="messages.php">Meddelanden: <?php  echo $newMessagesCount?></a></li>
      <li id="navright"><a href="logout.php">Logga ut</a></li>
      <li id="navrightbg"><a href="cart.php">Varukorgen: <?php  echo $getCartsCount?></a></li>
      <li id="navrightbg"><a href="profile.php"><?php  echo $userInfo['Fname']?></a></li>
      </ul>
  <?php
   } 
   ?>
   <br><br><label class="pagetitle">Betalningen</label><br><br>
   <table id="alltable">
  <tr>
    <th width="40%">Produkt</th>
    <th width="10%">Antal</th>
    <th width="20%">Pris</th>
    <th width="15%">Total</th>
  </tr>
  <?php
  if ($cartConnection->num_rows > 0) {
    while ($row = $cartConnection->fetch_assoc()) {
      $totCartCount =  $totCartCount + $row['cart_count'];
  ?>
  <tr>
    <td width="40%"><?php echo'<img height="100" width="80" src="cPanel/image/'.$row['c_prod_image'].'">'; echo $row['c_prod_titel'];?></td>
    <td width="10%"><?php echo $row['cart_count']; ?></td>
    <td width="20%"><?php echo $row['c_prod_price']; ?> kr</td>
    <td id="boldtext" width="15%"><?php $priceP = $row['c_prod_price']; $totalC = $row['cart_count']; $totalPrice = $priceP * $totalC; $tot = $tot + $totalPrice; echo $totalPrice; ?> kr</td>
  </tr>
  <?php
  }
} else {
  echo "Inga produkter";
}
  ?>
  <!-- betalningsfunktionen/knappen-->
  </table>
  <div class="formbox">
  <form method="post">
  <br><br><label id="boldtext">Betala summan: <?php echo $tot; ?> Kr </label>
  <input type="number" name="totSum"> 
  <input type="hidden" name="totinput" value="<?php echo $tot;?>">
  <input type="hidden" name="totcount" value="<?php echo $totCartCount;?>"> 
  <input id="sub" type="submit" name="buy" value="Betala">
  </form>
  </div>
  <div class="footer">
      <div class="nav">
        <ul>

          <li><a href="#">Om oss</a></li>
          <li><a href="#">Kontakta oss</a></li>
        </ul>
      </div>
   </div>

   <div class="footer-end">
      <p>Hemsidan skapat av: Ameer Alkadhimi, Pehr Häqqvist och Hamid Qurban - 2021</p>
   </div>
</body>
</html>